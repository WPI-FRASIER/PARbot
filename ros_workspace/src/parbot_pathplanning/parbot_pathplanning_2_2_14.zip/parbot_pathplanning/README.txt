Olivia Hugal
Jeffrey Orszulak

Running in Terminal:

TODO:
    Make diagonals cost weighted different than diagonal
    --> Random numbers "magically" don't work
    Need to do c space
    Need to have grid update when occupancy grid size changes
    Save and load maps - when turned on/off

roscore

START MAP SERVER - must be in parbot_pathplanning folder
rosrun map_servep_server rbe3002test-small.yaml

START RVIZ
rosrun rviz rviz

START PATH PLANNING SERVICE
rosrun parbot_pathplanning PARbot_dijkstra_on_occupancy_grid.py

MAKE CALL FOR PATH
rosrun parbot_pathplanning PARbot_dijkstra_return_path.py
