#!/usr/bin/env python
import roslib; roslib.load_manifest('JAJ_navigation')
import rospy
from nav_msgs.msg import OccupancyGrid
from geometry_msgs.msg import Point, Twist, Vector3
from JAJ_navigation.srv import JAJPlanPath
from math import pi, atan2, sqrt

class TurnCommand:
    def __init__(self, driver, orientation):
        self.driver = driver
        self.orientation = orientation

    def execute(self):
        start = rospy.get_rostime()
        turn_time = rospy.Duration.from_sec(self.orientation/(pi/6))
        while rospy.get_rostime() - start < turn_time:
            self.driver.drive(0, pi/6)
            rospy.sleep(0.005)

class DriveCommand:
    def __init__(self, driver, distance):
        self.driver = driver
        self.distance = distance

    def execute(self):
        self.driver.drive(0.5, 0)
        rospy.sleep(self.distance/0.5)

class PathFollower:
    def __init__(self, target):
        rospy.init_node("path_follower")
        self.pub = rospy.Publisher("cmd_vel", Twist)
        self.target = target
        self.commands = []
        self.path_exists = False
        
        rospy.loginfo("Waiting for service...")
        rospy.wait_for_service('path_planner')
        self.path_planner = rospy.ServiceProxy('path_planner', JAJPlanPath)
        self.sub = rospy.Subscriber("map", OccupancyGrid, self.plan)
        rospy.loginfo("Started up")

    def plan(self, grid):
        try:
            rospy.loginfo("Grid recieved")
            resp1 = self.path_planner(grid=grid, start=Point(1, 1, 0), target=self.target)
            rospy.loginfo("Path: %s"%[(p.x, p.y) for p in resp1.waypoints])
            self.commands = self.get_commands(resp1.waypoints)
            self.path_exists = True
        except rospy.ServiceException, e:
            rospy.loginfo("Service call failed: %s"%e)

    def get_commands(self, waypoints):
        commands = []
        orientation = 0
        while waypoints:
            current = waypoints.pop(0)
            if not waypoints: break
            future = waypoints[0]
            x = future.x - current.x
            y = future.y - current.y
            desired_orientation = atan2(y, x)
            if orientation != desired_orientation:
                commands.append(TurnCommand(self, desired_orientation - orientation))
            commands.append(DriveCommand(self, sqrt(x**2 + y**2)))
        return commands

    def drive(self, linear, angular):
        self.pub.publish(Twist(linear=Vector3(x=linear, y=0, z=0),
                               angular=Vector3(x=0, y=0, z=angular)))

    def run(self):
        while True:
            if self.path_exists:
                for command in self.commands:
                    command.execute()
                self.path_exists = False
            rospy.sleep(0.1)

if __name__ == "__main__":
    PathFollower(Point(9, 7, 0)).run()
