#!/usr/bin/env python
import roslib; roslib.load_manifest('JAJ_navigation')
import rospy
from a_star import *
from nav_msgs.msg import OccupancyGrid
from geometry_msgs.msg import Point
from JAJ_navigation.srv import JAJPlanPath, JAJPlanPathResponse

DELTA = 0.00001
CUTOFF = 50

def convert_occupancy_grid(grid):
    "Convert an occupancy grid into a graph"
    rospy.loginfo("Grid: %s"%grid)
    d = grid.info.resolution
    nodes = []
    for x in range(grid.info.width):
        for y in range(grid.info.height):
            if grid.data[y*grid.info.height + x] < CUTOFF:
                #node = Node((d/2+d*x, d/2+d*y))
                node = Node((d*x, d*y))
                for other in nodes:
                    if node.crow_distance_to(other) < (d + DELTA):
                        Link(node, other)
                nodes.append(node);

    return nodes
    

def plan_path(req):
    rospy.loginfo("Request made!")
    grid = convert_occupancy_grid(req.grid)
    rospy.loginfo("Grid size: %s"%(len(grid)))
    #rospy.loginfo("Grid: %s"%(sorted(p.loc for p in grid)))
    start = sorted([(node.crow_distance_to(Node((req.start.x, req.start.y))), node) for node in grid])[0][1]
    target = sorted([(node.crow_distance_to(Node((req.target.x, req.target.y))), node) for node in grid])[0][1]
    rospy.loginfo("start=%s, target=%s"%(start, target))
    path = a_star(start, target)
    rospy.loginfo("Path: %s"%path)
    return JAJPlanPathResponse([Point(x=p.loc[0], y=p.loc[1]) for p in path])
    
def run():
    rospy.init_node("path_planner_server")
    serv = rospy.Service('path_planner', JAJPlanPath, plan_path)
    rospy.loginfo("Started up")
    rospy.spin()

if __name__ == "__main__":
    run()
