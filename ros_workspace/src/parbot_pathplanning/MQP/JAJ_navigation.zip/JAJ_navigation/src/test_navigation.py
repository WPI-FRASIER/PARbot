#!/usr/bin/env python
import roslib; roslib.load_manifest('JAJ_navigation')
import rospy
from nav_msgs.msg import OccupancyGrid
from geometry_msgs.msg import Point
from JAJ_navigation.srv import JAJPlanPath

class Test:
    def __init__(self, target):
        rospy.init_node("test_path_planner")
        self.target = target
        
        rospy.loginfo("Waiting for service...")
        rospy.wait_for_service('path_planner')
        self.path_planner = rospy.ServiceProxy('path_planner', JAJPlanPath)
        self.sub = rospy.Subscriber("map", OccupancyGrid, self.plan)
        rospy.loginfo("Started up")

    def plan(self, grid):
        try:
            rospy.loginfo("Grid recieved")
            resp1 = self.path_planner(grid=grid, start=Point(1, 1, 0), target=self.target)
            rospy.loginfo("Path: %s"%[(p.x, p.y) for p in resp1.waypoints])
        except rospy.ServiceException, e:
            rospy.loginfo("Service call failed: %s"%e)

    def run(self):
        rospy.spin()

if __name__ == "__main__":
    Test(Point(9, 7, 0)).run()
