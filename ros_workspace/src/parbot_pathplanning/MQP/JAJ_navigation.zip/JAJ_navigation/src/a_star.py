#!/usr/bin/env python
from sys import maxint
from math import sqrt

import roslib; roslib.load_manifest('JAJ_navigation')
import rospy

class Node:
    def __init__(self, loc, score=maxint):
        self.loc = loc
        self.score = score
        self.links = []
        self.parent = None

    def get_links(self):
        "Return a list of all links connecting this node"
        return self.links
        
    def distance_from_start(self):
        "Returns the distance from the starting node"
        if self.parent != None:
            return self.crow_distance_to(self.parent) + self.parent.distance_from_start()
        else:
            return 0

    def crow_distance_to(self, node):
        "Returns the distance between these two nodes as the crow flies"
        return sqrt((self.loc[0] - node.loc[0])**2 + (self.loc[1] - node.loc[1])**2)

    def __repr__(self):
        return "<Node: location=%s parent=%s>"%(self.loc, self.parent.loc if self.parent else None)

class Link:
    def __init__(self, n1, n2):
        self.n1 = n1
        self.n2 = n2

        n1.links.append(self)
        n2.links.append(self)

    def get_other(self, node):
        "Return the node that isn't passed in"
        return self.n1 if self.n2 == node else self.n2

class Frontier:
    def __init__(self):
        self.list = []
        self.history = []

    def add(self, node):
        "Add a node if it's not already in the list"
        if node not in self.history:
            self.list.append(node)
            self.history.append(node)

    def get_best_choice(self):
        "Returns the lowest cost node and removes it from the frontier"
        self.list.sort()
        return self.list.pop(0)
    
    def peek_best_choice(self):
        "Returns the lowest cost node"
        self.list.sort(cmp=self.node_cmp)
        return self.list[0]

    def exists(self):
        "Whether or not there is more to explore"
        return True if self.list else False

    def node_cmp(self, n1, n2):
        "Compares nodes by distance to target"
        return cmp(n1.score, n2.score)

def a_star(start, target):
    """
    Return a path from start to target using the a_star algorithm.

    start: The node we are currently at.
    target: The node we want to get to.
    """
    frontier = Frontier()

    def h(n): return target.crow_distance_to(n)
    def g(n, node): return n.crow_distance_to(node) + node.distance_from_start()

    def expand(node):
        for link in node.get_links():
            n = link.get_other(node)
            score = h(n) + g(n, node)
            if score < n.score:
                n.score = score
                n.parent = node
                frontier.add(n)


    start.score = h(start) 
    frontier.add(start)
    while frontier.exists() and frontier.peek_best_choice().score < target.score:
        node = frontier.get_best_choice()
        if node == target: break
        expand(node)

    node = target
    path = [node]
    while node != start:
        for link in node.get_links():
            n = link.get_other(node)
        node = node.parent
        path.append(node)
    path.reverse()
    return path

if __name__ == "__main__":
    n1 = Node([0, 0]);   n2 = Node([1, 0]);  n3 = Node([2, 0]);  n4 = Node([3, 0])
    n5 = Node([0, 1]);   n6 = Node([1, 1]);  n7 = Node([2, 1]);  n8 = Node([3, 1])
    n9 = Node([0, 2]);  n10 = Node([1, 2]); n11 = Node([2, 2]); n12 = Node([3, 2])
    n13 = Node([0, 3]); n14 = Node([1, 3]); n15 = Node([2, 3]); n16 = Node([3, 3])

    Link(n1, n5); Link(n5, n6); Link(n5, n9)
    Link(n9, n13); Link(n13, n14)
    Link(n14, n15); Link(n11, n15); Link(n11, n12); Link(n15, n16); Link(n12, n16)
    Link(n12, n8); Link(n8, n4); Link(n4, n3)
    Link(n6, n10); Link(n9, n10); Link(n10, n14); Link(n10, n11)
    #Link(n7, n3); Link(n7, n6); Link(n7, n11); Link(n7, n8)
    Link(n2, n1); Link(n2, n6); Link(n2, n3)

    for n in a_star(n10, n12):
        print n.loc

# Solution 1
# [0, 0]
# [0, 1]
# [1, 1]
# [1, 2]
# [2, 2]
# [3, 2]
# [3, 1]
# [3, 0]
# [2, 0]

# Solution 2
# [0, 0]
# [0, 1]
# [0, 2]
# [0, 3]
# [1, 3]
# [2, 3]
# [2, 2]
# [3, 2]
# [3, 1]
# [3, 0]
# [2, 0]
