#!/usr/bin/env python
import roslib; roslib.load_manifest('JAJ_localization')
import rospy
from geometry_msgs.msg import Pose, PoseStamped, PoseWithCovarianceStamped, PoseArray
from nav_msgs.msg import OccupancyGrid, MapMetaData, Odometry
import numpy as np
import matplotlib.pyplot as plt
from sys import maxint
import random, tf

from JAJ_localization.msg import LineMap, Line
from line_core import *
from localization import get_transform, get_vector, grid_get, grid_iter, grid_put

class TFPublisher():
    def __init__(self):
        rospy.init_node("map_tf_publisher")
        self.pose = None
        self.sub = rospy.Subscriber("robot_pose", PoseStamped, self.pose_callback)

        rospy.loginfo("map tf publisher started up")

    def pose_callback(self, stamped_pose):
        rospy.loginfo("Stamped pose received")
        self.pose = stamped_pose.pose
        
    def run(self):
        br = tf.TransformBroadcaster()
        prevTime = rospy.Time.now()
        while not rospy.is_shutdown():
            if self.pose != None:
                time = rospy.Time.now()
                # print "updating tf at %s"%(time - prevTime)
                prevTime = time
                position = [-self.pose.position.x, -self.pose.position.y, -self.pose.position.z]
                orientation = [self.pose.orientation.x, self.pose.orientation.y,
                               self.pose.orientation.z, self.pose.orientation.w]
                orientation = tf.transformations.quaternion_inverse(orientation)
                _, _, theta = tf.transformations.euler_from_quaternion(orientation)
                orientation = tf.transformations.quaternion_from_euler(0, 0, -theta)
                # br.sendTransform(position, orientation,
                #                  rospy.Time.now(), "/map", "/base_footprint")
                br.sendTransform([0, 0, 0], [0, 0, 0, 1],
                                 time, "/map", "/base_footprint")
            rospy.sleep(0.02)

if __name__ == "__main__":
    TFPublisher().run()
