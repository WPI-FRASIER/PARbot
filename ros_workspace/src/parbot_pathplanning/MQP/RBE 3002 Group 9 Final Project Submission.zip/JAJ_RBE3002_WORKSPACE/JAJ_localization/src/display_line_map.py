#!/usr/bin/env python
"""
Provides a graphical view of a line map.

Subscribes to:
- line_map: LineMap The line map to display
"""

import roslib; roslib.load_manifest('JAJ_localization')
import rospy
from JAJ_localization.msg import LineMap, Line
import numpy as np
import matplotlib.pyplot as plt
from line_core import *

class LineMapViewer():
    def __init__(self):
        rospy.init_node("line_map_viewer")
        self.sub = rospy.Subscriber("line_map", LineMap, self.map_callback)
        rospy.loginfo("Started up")
    
    def map_callback(self, line_map):
        rospy.loginfo("Message received")
        lines = line_map_msg_to_lines(line_map)

        print len(lines)
        for line in lines:
            line.plot()
        plt.axis('equal')
        plt.show()

    def run(self):
        rospy.spin()

if __name__ == "__main__":
    LineMapViewer().run()
