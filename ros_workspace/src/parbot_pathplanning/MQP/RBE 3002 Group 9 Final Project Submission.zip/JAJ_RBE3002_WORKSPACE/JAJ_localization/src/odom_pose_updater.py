#!/usr/bin/env python
"""
Updates the robot position published from the particle filter based
off of the updated data gathered from the odometry.

Subscribes to:
- particle_pose: PoseStamped The pose that the particle filter guesses.
- odom: Odometry The odometry reading gathered.

Publishes to:
- robot_pose: PoseStamped The pose of the robot from adding the
  particle filter an the odometry delta.
"""

import roslib; roslib.load_manifest('JAJ_localization')
import rospy
from nav_msgs.msg import OccupancyGrid, Odometry
from geometry_msgs.msg import Point, Pose, PoseStamped, PoseArray, PoseWithCovarianceStamped
from math import pi, atan2, sqrt, cos, sin
import tf

FRAME = "/base_footprint"

def pose_distance_to_point(pose, (x, y)):
    return sqrt((pose.position.x - x)**2 + (pose.position.y - y)**2)
        
class OdomPoseUpdater:
    def __init__(self):
        rospy.init_node("odom_pose_updater")
        self.base_odom = None
        self.current_odom = None
        self.robot_pose = None
        
        self.pose_sub = rospy.Subscriber("particle_pose", PoseStamped, self.update_pose)
        self.odom_sub = rospy.Subscriber("odom", Odometry, self.update_odom)
        self.pose_pub = rospy.Publisher("robot_pose", PoseStamped)
        rospy.loginfo("Started up")
        
    def update_pose(self, pose):
        rospy.loginfo("New pose received")
        self.robot_pose = pose
        self.base_odom = self.current_odom
    
    def update_odom(self, odom):
        # rospy.loginfo("New odom received")
        self.current_odom = odom.pose

        if self.robot_pose == None:
            rospy.logwarn("No robot pose to use received")
        elif self.base_odom == None:
            rospy.logwarn("No base odometry to use received")
        else:
            self.update_steering()

    def update_steering(self):
        ## Calculate location
        orientation = self.robot_pose.pose.orientation
        current_orientation = self.current_odom.pose.orientation
        base_orientation = self.base_odom.pose.orientation
        _, _, theta = tf.transformations.euler_from_quaternion((
                orientation.x, orientation.y, orientation.z, orientation.w))
        _, _, current_theta = tf.transformations.euler_from_quaternion((
                current_orientation.x, current_orientation.y, current_orientation.z, current_orientation.w))
        _, _, base_theta = tf.transformations.euler_from_quaternion((
                base_orientation.x, base_orientation.y, base_orientation.z, base_orientation.w))
        theta += (current_theta - base_theta)

        dx = (self.current_odom.pose.position.x - self.base_odom.pose.position.x)
        dy = (self.current_odom.pose.position.y - self.base_odom.pose.position.y)
        r = sqrt(dx**2 + dy**2) # Don't like backwards
        x = self.robot_pose.pose.position.x + r*cos(theta)
        y = self.robot_pose.pose.position.y + r*sin(theta)
        

        # Publish pose
        pose = PoseStamped()
        pose.pose.position.x = x
        pose.pose.position.y = y
        qx, qy, qz, qw = tf.transformations.quaternion_from_euler(0, 0, theta)
        pose.pose.orientation.x, pose.pose.orientation.y = qx, qy
        pose.pose.orientation.z, pose.pose.orientation.w = qz, qw
        pose.header.frame_id = FRAME
        self.pose_pub.publish(pose)

    def run(self):
        rospy.spin()

if __name__ == "__main__":
    OdomPoseUpdater().run()
