#!/usr/bin/env python
import roslib; roslib.load_manifest('JAJ_localization')
import rospy
from nav_msgs.msg import OccupancyGrid
from geometry_msgs.msg import Point, Pose, PoseStamped
from JAJ_localization.srv import JAJRegisterGrid, JAJRegisterGridResponse
from math import pi, cos, sin
from sys import maxint
import numpy as np
import tf

def get_transform(x, y, theta):
    return np.matrix([[cos(theta), -sin(theta), 0, x],
                      [sin(theta),  cos(theta), 0, y],
                      [         0,           0, 1, 0],
                      [         0,           0, 0, 1]])

def get_vector(x, y):
    return np.array([[x], [y], [0], [1]])

def grid_get(grid, x, y): return grid.data[grid.info.width*y + x]
def grid_put(grid, x, y, val): grid.data[grid.info.width*y + x] = val

def grid_iter(grid):
    for x in range(0, grid.info.width):
        for y in range(0, grid.info.height):
            yield x, y

class Localizer():
    def __init__(self):
        rospy.init_node("turtlebot_localizer")
        self.pub = rospy.Publisher("robot_pose", PoseStamped)
        self.global_sub = rospy.Subscriber("map_init", OccupancyGrid, self.global_map_callback)
        self.local_sub = rospy.Subscriber("local_map", OccupancyGrid, self.map_callback)
        self.register_grid = rospy.ServiceProxy("map_register_grid", JAJRegisterGrid)
        rospy.loginfo("Started up")
        self.global_map = None

    def global_map_callback(self, grid):
        self.global_map = grid
        
    def map_callback(self, grid):
        rospy.loginfo("Message received")
        if self.global_map == None: return

        points = []
        for x in range(self.global_map.info.width):
            for y in range(self.global_map.info.height):
                if grid_get(self.global_map, x, y) > 50: continue
                for theta in [2*pi*i/12.0 for i in range(12)]:
                    points.append((x, y, theta))
        rospy.loginfo("Number of samples %s"%(len(points)))

        best_fit = maxint
        best = (0, 0, 0)
        for x, y, theta in points:
            fit = self.test_fit(grid, x, y, theta)
            if fit < best_fit:
                best_fit = fit
                best = x, y, theta
        rospy.loginfo("%0.2f: %s"%(best_fit, best))
        
        self.register_grid(grid=grid, pose=Point(x=10, y=4, z=0))

        x, y, theta = best
        p = Pose()
        p.position.x, p.position.y = x, y
        p.orientation.z = theta
        self.pub.publish(PoseStamped(pose=p))

    def test_fit(self, grid, x, y, theta):
        transform = get_transform(x, y, theta)

        fit = 0 # Lower is better!
        dp = 0
        for x, y in grid_iter(grid):
            local_value = grid_get(grid, x, y)
            if local_value == -1: continue
            cosmic = transform * get_vector(int(round(x - grid.info.origin.position.x)),
                                            int(round(y - grid.info.origin.position.y)))
            
            gx, gy = int(round(cosmic[0,0])), int(round(cosmic[1,0]))
            if not (0 <= gx and gx < self.global_map.info.width \
                        and 0 <= gy and gy < self.global_map.info.height):
                continue
            global_value = grid_get(self.global_map, gx, gy)
            
            if global_value == -1: pass
            else:
                fit += abs(local_value - global_value)
                dp += 1

        if dp != 0: return fit/float(dp)
        else: return maxint
        
    def run(self):
        while not rospy.is_shutdown():
            rospy.sleep(0.1)

if __name__ == "__main__":
    Localizer().run()

