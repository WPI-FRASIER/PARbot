#!/usr/bin/env python
import roslib; roslib.load_manifest('JAJ_localization')
import rospy
from nav_msgs.msg import OccupancyGrid, MapMetaData
from geometry_msgs.msg import Pose
from sensor_msgs.msg import LaserScan
from math import pi, cos, sin
import numpy as np
import tf

OCCUPIED = 100
FREE = 0

SIZE = 28
SAMPLE = 2

class LocalGrid():
    def __init__(self):
        rospy.init_node("local_grid_server")
        self.pub = rospy.Publisher("local_map", OccupancyGrid)
        self.sub = rospy.Subscriber("scan", LaserScan, self.scan_callback)
        self.origin = None
        self.resolution = .122414 # 0.061825
        rospy.loginfo("Started up")
    
    def make_occupancy_grid(self):
        "Make an empty grid that can fit all of the data from the laser scan"
        #origin = Pose(x=scan.range_max*abs(cos(scan.angle_min)),y=0)
        grid = OccupancyGrid(info=MapMetaData(resolution=self.resolution, width=SIZE, height=SIZE),
                             data = [-1 for i in range(SIZE**2)])
        grid.info.origin.position.x = SIZE/2
        grid.info.origin.position.y = 0
        self.origin = grid.info.origin
        #print grid.info.origin.position.x, grid.info.origin.position.y
        return grid

    def update_with_reading(self, grid, theta, r, occupancy=OCCUPIED):
        x = int(round(r*cos(pi/2 + theta)/grid.info.resolution + grid.info.origin.position.x))
        y = int(round(r*sin(pi/2 + theta)/grid.info.resolution + grid.info.origin.position.y))
        #rospy.loginfo("(%s, %s) is occupied."%(x, y))
        #print len(grid.data), grid.info.width*y + x
        if not ((0 <= x and x < grid.info.width)
                and (0 <= y and y < grid.info.height)):
            return # Bad data point
        if grid.data[grid.info.width*y + x] != OCCUPIED:
            grid.data[grid.info.width*y + x] = occupancy

    def scan_callback(self, scan):
        # rospy.loginfo("Message received")
        grid = self.make_occupancy_grid()

        theta = scan.angle_min
        for r in scan.ranges[::SAMPLE]:
            if r > scan.range_max:
                pass
            elif scan.range_min < r and r < scan.range_max:
                for s in np.linspace(0, r, num=(r/self.resolution)*3):
                    self.update_with_reading(grid, theta, s, FREE)
                self.update_with_reading(grid, theta, r)
            else:
                if r > SIZE/self.resolution: r = SIZE/self.resolution
                for s in np.linspace(0, scan.range_max, num=(scan.range_max/self.resolution)*3):
                    self.update_with_reading(grid, theta, s, FREE)
            theta += SAMPLE * scan.angle_increment

        # TODO: Time?
        self.pub.publish(grid)
        # rospy.loginfo("Message published")

    def run(self):
        br = tf.TransformBroadcaster()
        while not rospy.is_shutdown():
            if self.origin != None:
                br.sendTransform((0, 15.75, 0),
                                 tf.transformations.quaternion_from_euler(0, 0, -pi/2),
                                 rospy.Time.now(), "/map", "/base_link")
            rospy.sleep(0.1)

if __name__ == "__main__":
    LocalGrid().run()
