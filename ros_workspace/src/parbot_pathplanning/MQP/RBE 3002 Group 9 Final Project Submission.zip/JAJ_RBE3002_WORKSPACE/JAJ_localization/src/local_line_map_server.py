#!/usr/bin/env python
"""
Generates the local line map based off of the scan data.

Subscribes to:
- scan: LaserScan The laser scan to convert to a local line map.

Publishes to:
- global_line_map: LineMap The local line map.
"""

import roslib; roslib.load_manifest('JAJ_localization')
import rospy
from JAJ_localization.msg import LineMap
from sensor_msgs.msg import LaserScan
import numpy as np
import matplotlib.pyplot as plt
from line_core import *

#CLOSE_ENOUGH = 1
LINE_TOLERANCE = 0.02

class LineMapping():
    def __init__(self):
        rospy.init_node("line_mapping")
        self.pub = rospy.Publisher("local_line_map", LineMap)
        self.sub = rospy.Subscriber("scan", LaserScan, self.scan_callback)
        rospy.loginfo("LineMapping started up")
    
    def scan_callback(self, scan):
        rospy.loginfo("Message received")

        print scan.angle_min, scan.angle_max
        print scan.range_min, scan.range_max

        # Get all r, theta
        data = [] # [(r, theta, x, y), ...]
        theta = scan.angle_min
        for r in scan.ranges[::2]:
            if scan.range_min < r and r < scan.range_max:
                data.append((r, theta, r*cos(theta), r*sin(theta)))
            theta += 2 * scan.angle_increment

        lines = get_lines(data, LINE_TOLERANCE)
        rospy.loginfo("Lines segmented")

        # print len(lines)
        # for line in lines:
        #     line.plot()
        # plt.axis('equal')
        # plt.show()
        
        self.pub.publish(LineMap(lines=[l.to_line_msg() for l in lines]))
        rospy.loginfo("Message published")

    def run(self):
        while not rospy.is_shutdown():
            rospy.sleep(0.1)

if __name__ == "__main__":
    LineMapping().run()
