#!/usr/bin/env python
"""
This file provides a line map viewer that shows where the local map
super-imposed on top of the global line map. This is useful for
debugging and visualizing whath the robot sees.

Subscribes to:
- global_line_map: LineMap that contains the global line map
- local_line_map: LineMap that contains the local line map
- robot_pose: PoseStamped that contains where the robot thinks it is
"""

import roslib; roslib.load_manifest('JAJ_localization')
import rospy
from JAJ_localization.msg import LineMap, Line
from geometry_msgs.msg import PoseStamped
import numpy as np
import matplotlib.pyplot as plt
from line_core import *
import time, tf

class LineMapViewer():
    def __init__(self):
        rospy.init_node("line_map_viewer")
        self.global_map = None
        self.local_map = None
        self.robot_pose = None
        self.global_sub = rospy.Subscriber("global_line_map", LineMap, self.global_map_callback)
        self.local_sub = rospy.Subscriber("local_line_map", LineMap, self.local_map_callback)
        self.robot_pose_sub = rospy.Subscriber("robot_pose", PoseStamped, self.robot_pose_callback)
        rospy.loginfo("Started up")
    
    
    def global_map_callback(self, line_map):
        rospy.loginfo("Global map received")
        self.global_map = line_map
        
    def local_map_callback(self, line_map):
        rospy.loginfo("Local map received")
        self.local_map = line_map

    def robot_pose_callback(self, pose):
        rospy.loginfo("Robot pose received")
        self.robot_pose = pose.pose

    def run(self):
        while not rospy.is_shutdown():
            if self.global_map != None and self.local_map != None and self.robot_pose != None:
                global_map = line_map_msg_to_lines(self.global_map)
                local_map = line_map_msg_to_lines(self.local_map)
        
                print len(global_map), len(local_map)
                
                for line in global_map:
                    line.plot("b")
                
                orientation = self.robot_pose.orientation
                _, _, theta = tf.transformations.euler_from_quaternion((orientation.x, orientation.y,
                                                                        orientation.z, orientation.w))
                print theta
                
                for line in local_map:
                    print [(x, y) for _, _, x, y in line.points]
                    line.set_origin(self.robot_pose.position.x, self.robot_pose.position.y, theta)
                    print [(x, y) for _, _, x, y in line.points]
                    line.plot()
                
                plt.axis('equal')
                plt.show()
                
            rospy.sleep(0.1)

if __name__ == "__main__":
    LineMapViewer().run()
