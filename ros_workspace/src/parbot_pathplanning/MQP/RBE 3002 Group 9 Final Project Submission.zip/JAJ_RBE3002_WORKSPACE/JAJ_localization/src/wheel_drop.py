#!/usr/bin/env python
"""
Updates the robot position published from the particle filter based
off of the updated data gathered from the odometry.

Subscribes to:
- /turtlebot_node/sensor_state: TurtlebotSensorState Sensor readings from the turtlbot.

Publishes to:
- wheel_drop: WheelDrop Whether or not the turtlebot is on the ground.
"""

import roslib; roslib.load_manifest('JAJ_localization')
import rospy
from turtlebot_node.msg import TurtlebotSensorState
from sys import maxint

from JAJ_localization.msg import WheelDrop

class WheelDropSensor():
    def __init__(self):
        rospy.init_node("wheel_drop_sensor")
        self.prev = False
        self.sub = rospy.Subscriber("/turtlebot_node/sensor_state", TurtlebotSensorState, self.state_callback)
        self.pub = rospy.Publisher("wheel_drop", WheelDrop)

        rospy.loginfo("Started up")

    def state_callback(self, state):
        on_ground = not (28 & state.bumps_wheeldrops)
        if on_ground != self.prev:
            rospy.loginfo("On ground: %s"%on_ground)
            self.prev = on_ground
            self.pub.publish(WheelDrop(on_ground=on_ground))
        
    def run(self):
        rospy.spin()

if __name__ == "__main__":
    WheelDropSensor().run()
