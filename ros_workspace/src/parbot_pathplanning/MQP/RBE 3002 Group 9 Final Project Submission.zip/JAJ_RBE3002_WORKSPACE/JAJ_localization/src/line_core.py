"""
Core line map library:
- line_fit(data): Fit a line to the data
- get_lines(data): Recursively calculate the line map from a data.
- Various other utilities
"""


from math import pi, cos, sin, atan2, sqrt
import matplotlib.pyplot as plt
from JAJ_localization.msg import Line as LineMsg
from geometry_msgs.msg import Point

def line_fit(data):
    """
    The data that needs to be fit.

    data: [(r, theta), ...]
    """
    R, alpha = 0, 0

    ## Find alpha
    # Using the equation found in chernovas notes.
    y1, y2, x1, x2 = 0, 0, 0, 0
    for r, theta in data:
        y1 += r**2 * sin(2*theta)
        x1 += r**2 * cos(2*theta)
        for j, phi in data:
            y2 += r*j*cos(theta)*sin(phi)
            x2 += r*j*cos(theta + phi)
    y = y1 - (2.0/len(data))*y2
    x = x1 - (1.0/len(data))*x2
    alpha = 0.5 * atan2(y, x) - pi/2

    ## Find R
    for r, theta in data:
        R += r * cos(theta - alpha)
    R /= len(data)

    ## Correct for negative Rs and redundant alphas
    if R < 0:
        R = -R
        alpha += pi
    alpha %= 2*pi
    
    return R, alpha

def distance(p1, p2):
    _, _, x1, y1 = p1
    _, _, x2, y2 = p2
    return sqrt((x1-x2)**2 + (y1-y2)**2)

def distance_from_line((r, theta), (x, y)):
    """
    See: http://www.tpub.com/math2/8.htm

    line: defined as (r, theta)
    point: defined as (x, y)
    """
    return x*cos(theta) + y*sin(theta) - r

def get_lines(data, line_tolerance=0.1, similarity_tolerance=0):
    lines = []
    possible_lines = [Line(data, line_tolerance)]
    while possible_lines:
        line = possible_lines.pop()
        if line.needs_segmenting():
            possible_lines.extend(line.segment())
        else:
            lines.append(line)

    # merged_lines = []
    # while lines:
    #     line = lines.pop()
    #     for l in lines:
    #         print line.score(l)
    #         if line.score(l) < similarity_tolerance:
    #             print "\tMerged"
    #             line.merge(l)
    #             lines.remove(l)
    #     merged_lines.append(line)

    # for line in merged_lines:
    #     print line.r, line.theta
    
    return lines

class Line:
    def __init__(self, points, line_tolerance=0.01):
        self.points = points
        self.r, self.theta = line_fit([(r, theta) for r, theta, _, _ in self.points])
        self.line_tolerance = line_tolerance

    def needs_segmenting(self):
        checking = False
        for _, _, x, y in self.points:
            if self.distance(x, y) > self.line_tolerance:
                # print self.distance(x, y)
                if not checking:
                    checking = True
                    continue
                else:
                    return True
                checking = False
        return False

    def segment(self):
        r, theta = line_fit([self.points[0][:2], self.points[-1][:2]])
        farthest, farthest_dist = 0, 0
        # dists = []
        for i, (_, _, x, y) in enumerate(self.points):
            dist = abs(distance_from_line((r, theta), (x, y)))
            # dists.append((i, dist))
            if dist > farthest_dist:
                farthest_dist = dist
                farthest = i
        # print farthest, farthest_dist, dists

        ## Generate lines
        if (farthest + 1) == len(self.points):
            print "Throwing away end point"
            return [Line(self.points[:-1], self.line_tolerance)]
        elif farthest == 0:
            print "Throwing away starting point"
            return [Line(self.points[1:], self.line_tolerance)]
        else:
            lines = []
            data = self.points[:farthest+1]
            if len(data) > 2:
                lines.append(Line(data, self.line_tolerance))
            data = self.points[farthest:]
            if len(data) > 2:
                lines.append(Line(data, self.line_tolerance))
            return lines

    def merge(self, oth):
        self.points.extend(oth.points)
        self.points.sort()
        # self.r, self.theta = line_fit([(r, theta) for r, theta, _, _ in self.points])

    def plot(self, color=None):
        # TODO: Fix hack
        (x1, y1), (x2, y2) = self.points[0][2:], self.points[-1][2:]
        xs, ys = [x1, x2], [y1, y2]
        if color:
            plt.plot(xs, ys, marker="*", color=color)
        else:
            plt.plot(xs, ys, marker="*")

    def to_line_msg(self):
        # TODO: make real endpoints
        p1 = Point(x=self.points[0][2], y=self.points[0][3])
        p2 = Point(x=self.points[-1][2], y=self.points[-1][3])
        return LineMsg(r=self.r, theta=self.theta, p1=p1, p2=p2)

    def distance(self, x, y):
        return distance_from_line((self.r, self.theta), (x, y))

    def set_origin(self, gx, gy, gtheta):
        "x, y and theta are with respect to the new origin"
        points = []
        for _, _, x0, y0 in self.points:
            x = (x0*cos(gtheta) - y0*sin(gtheta)) + gx
            y = (x0*sin(gtheta) + y0*cos(gtheta)) + gy
            r = sqrt(x**2 + y**2)
            theta = atan2(y, x)
            points.append((r, theta, x, y))
        self.points = points
        # TODO: deal with hack with endpoints
        self.r, self.theta = line_fit([(r, theta) for r, theta, _, _ in self.points])

    def score(self, oth):
        return (self.theta - oth.theta)**2 + (self.r - oth.r)**2

    def __repr__(self):
        return "<Line: r=%s, theta=%s, data-points=%s>"%(self.r, self.theta, len(self.points))

## UTILS for dealing with messages
def line_map_msg_to_lines(msg):
    lines = []
    for line in msg.lines:
        x1, y1 = line.p1.x, line.p1.y
        r1, theta1 = sqrt(x1**2 + y1**2), atan2(y1, x1)
        x2, y2 = line.p2.x, line.p2.y
        r2, theta2 = sqrt(x2**2 + y2**2), atan2(y2, x2)
        line = Line([(r1, theta1, x1, y1), (r2, theta2, x2, y2)])
        line.r = line.r
        line.theta = line.theta
        lines.append(line)
    return lines
