#!/usr/bin/env python
"""
Runs a particle filter that tries to localize the robot based off of
the incoming odometry data and the local line map.

Subscribes to:
- odom: Odometry The odometry reading gathered.
- global_line_map: LineMap The list of maps that form the global line map.
- local_line_map: LineMap nThe list of maps that form the local line map. 
- initialpose: PoseWithCovarianceStamped A pose hint provided by rviz.
- map_init: OccupancyGrid The initial map for checking if particles are in walls.
- map_init_cspace: OccupancyGrid The cspace occupancy grid for generating locations to check.
- wheel_drop: WheelDrop The reading of the wheel drop sensors.

Publishes to:
- particle_pose: PoseStamped The pose that the particle filter guesses.
- particles: PoseArray List of all of the particles for visualization.
- particle_pose_valid: Bool Whether or not the particle filter is running kidnapping code.
- good_particles: PoseArray List of the good particles for visualization.
- best_particles: PoseArray List of the best particles for visualization.
"""

import roslib; roslib.load_manifest('JAJ_localization')
import rospy
from std_msgs.msg import Bool
from geometry_msgs.msg import Pose, PoseStamped, PoseWithCovarianceStamped, PoseArray
from nav_msgs.msg import OccupancyGrid, MapMetaData, Odometry
import numpy as np
import matplotlib.pyplot as plt
from sys import maxint
import random, tf
from dynamic_reconfigure.server import Server as DynamicReconfigureServer

from JAJ_localization.msg import LineMap, Line, WheelDrop
import JAJ_localization.cfg.ParticleFilterConfig as Config
from line_core import *
from localization import get_transform, get_vector, grid_get, grid_iter, grid_put

# Fake kidnapping
# rostopic pub -1 /wheel_drop JAJ_localization/WheelDrop "{on_ground: false}"; rostopic pub -1 /wheel_drop JAJ_localization/WheelDrop "{on_ground: true}"

FRAME = "/base_footprint"

def randrange(min, max):
    return min + ((max - min) * random.random())

def roulette_wheel(particles):
    total = sum(particle.fit for particle in particles)
    selection = randrange(0, total)
    accum, i = particles[0].fit, 0
    while accum <= selection:
        i += 1
        accum += particles[i].fit
#    print i
    return particles[i].copy()

class Particle:
    def __init__(self, particle_filter, x, y, theta):
        self.particle_filter = particle_filter
        self.global_line_map = particle_filter.global_line_map
        self.x = x
        self.y = y
        self.theta = theta
        self.fit = None

    def get_fit(self, lines):
        "WARNING: unsafely modifies lines"
        for line in lines:
            line.set_origin(self.x, self.y, self.theta)

        self.fit = sum(min(line.score(gl) for gl in self.global_line_map)
                       for line in lines) / len(lines)
        self.fit = 4 - self.fit
        if self.fit < 0: self.fit = 0
        return self.fit

    def is_within_map(self, grid):
        x, y = int(round(self.x / grid.info.resolution)), int(round(self.y / grid.info.resolution))
        if not (0 <= x and x < grid.info.width and 0 <= y and y < grid.info.height):
                return False
        return grid_get(grid, x, y) == 0 # TODO: parameterize?

    def move(self, dx, dy, dtheta):
        dx = random.gauss(dx, max(self.particle_filter.K*dx, self.particle_filter.K_min))
        dy = random.gauss(dy, max(self.particle_filter.K*dy, self.particle_filter.K_min))
        r = sqrt(dx**2 + dy**2)
        self.x += r * cos(self.theta)
        self.y += r * sin(self.theta)
        self.theta += random.gauss(dtheta, max(self.particle_filter.K*dtheta, self.particle_filter.K_min/pi))

    def get_pose(self):
        pose = Pose()
        pose.position.x = self.x
        pose.position.y = self.y
        x, y, z, w = tf.transformations.quaternion_from_euler(0, 0, self.theta)
        pose.orientation.x, pose.orientation.y = x, y
        pose.orientation.z, pose.orientation.w = z, w

        return pose

    def get_stamped_pose(self):
        robot = PoseStamped()
        robot.pose = self.get_pose()
        robot.header.frame_id = FRAME

        return robot

    def copy(self):
        return Particle(self.particle_filter, self.x, self.y, self.theta)

class ParticleFilter():
    def __init__(self):
        rospy.init_node("particle_filter")
        self.global_line_map = None
        self.global_line_map_msg = None
        self.global_map = None
        self.cspace_map = None
        self.world_size = None # ((xmin, ymin), (xmax, ymax))
        self.particles = None
        self.current_odom = None
        self.pose = None
        self.best_particle = None
        self.last_odom = None

        # Relocalizing
        self.relocalizing_time = 0
        self.relocalizing = False
        self.was_lifted = False

        # Dynamic reconfigure
        self.num_particles = 1000
        self.max_tries = 100
        self.replacement_rate = 0.01
        self.user_doubt = 0.1
        self.replacement_bias = 0.1
        self.num_top_particles = 100
        self.K = 0.00125 # magic k, K? defines sigma in particle. K?
        self.K_min = 0 # minimum magic k, K? defines sigma in particle. K?
        self.dyn_reconf_server = DynamicReconfigureServer(Config, self.reconfigure) 

        
        self.global_sub = rospy.Subscriber("global_line_map", LineMap, self.global_map_callback)
        self.local_sub = rospy.Subscriber("local_line_map", LineMap, self.local_map_callback)
        self.local_sub = rospy.Subscriber("initialpose", PoseWithCovarianceStamped, self.pose_callback)
        self.world_sub = rospy.Subscriber("map_init", OccupancyGrid, self.world_callback)
        self.cspac_sub = rospy.Subscriber("map_init_cspace", OccupancyGrid, self.cspace_callback)
        self.odom_sub = rospy.Subscriber("odom", Odometry, self.odom_callback)
        self.wheel_drop_sub = rospy.Subscriber("wheel_drop", WheelDrop, self.wheel_drop_callback)
        self.particle_pub = rospy.Publisher("particles", PoseArray)
        self.robot_pose_pub = rospy.Publisher("particle_pose", PoseStamped)
        self.robot_pose_valid_pub = rospy.Publisher("particle_pose_valid", Bool)

        self.good_particle_pub = rospy.Publisher("good_particles", PoseArray)
        self.best_particle_pub = rospy.Publisher("best_particles", PoseArray)

        rospy.loginfo("ParticleFilter started up")
        
    def reconfigure(self, config, level):
        rospy.loginfo("Got reconfigure request!")
        print config
        self.num_particles = config["num_particles"]
        self.num_top_particles = int(config["num_top_particles"])
        self.max_tries = config["max_tries"]
        self.replacement_rate = config["replacement_rate"]
        self.user_doubt = config["user_doubt"]
        self.replacement_bias = config["replacement_bias"]
        self.K = config["K"]
        self.K_min = config["K_min"]
        return config

    def initialize_particles(self, bias=None):
        self.particles = [self.random_particle(bias) for i in range(self.num_particles)]

    def random_particle(self, bias=None):
        if bias == None:
            for i in range(self.max_tries):
                particle = Particle(self,
                                    randrange(self.world_size[0][0], self.world_size[1][0]),
                                    randrange(self.world_size[0][1], self.world_size[1][1]),
                                    randrange(0, 2*pi))
                if particle.is_within_map(self.global_map): return particle
            return particle
        else:
            for i in range(self.max_tries):
                particle = Particle(self,
                                    random.gauss(bias[0][0], bias[1][0]),
                                    random.gauss(bias[0][1], bias[1][1]),
                                    random.gauss(bias[0][2], bias[1][2]))
                if particle.is_within_map(self.global_map): return particle
            return particle
    
    def global_map_callback(self, line_map):
        rospy.loginfo("Global line map received")
        self.global_line_map = line_map_msg_to_lines(line_map)
        if self.particles:
            for particle in self.particles:
                particle.global_line_map = self.global_line_map
        
    def local_map_callback(self, line_map):
        if self.global_line_map == None:
            rospy.logwarn("Local line map received, but no global line map received.")
            return
        elif self.particles == None:
            rospy.logwarn("Local line map received, but particles have not been initialized.")
            return
        elif self.current_odom == None:
            rospy.logwarn("Local line map received, but odometry has not been initialized.")
            return

        self.global_line_map_msg = line_map
        lines = line_map_msg_to_lines(line_map)
        # rospy.loginfo("Local line map received")
        rospy.loginfo("%s local lines, %s global lines"\
                          %(len(lines), len(self.global_line_map)))

        self.move_particles()

        good_particles = []
        for particle in self.particles:
            lines = line_map_msg_to_lines(line_map)
            fit = particle.get_fit(lines)
            good_particles.append((fit, (particle.x, particle.y, particle.theta)))

        good_particles.sort(reverse=True)
        good_particles = [particle for _, particle in good_particles][:self.num_top_particles]

        avg_particle = np.average(good_particles, axis=0)
        std = np.std(good_particles, axis=0)

        best_particle = Particle(self, 0, 0, 0)
        best_particles = []
        for particle in good_particles:
            if abs(avg_particle[0] - particle[0]) <= std[0] \
                    and abs(avg_particle[1] - particle[1]) <= std[1] \
                    and abs(avg_particle[2] - particle[2]) <= std[2]:
                best_particles.append(particle)

        ## DEBUG
        particles = PoseArray(poses=[Particle(self, *particle).get_pose()
                                     for particle in good_particles])
        particles.header.frame_id = FRAME
        self.good_particle_pub.publish(particles)
        
        # avg_particle = np.average(good_particles, axis=0)
        # std = np.std(good_particles, axis=0)

        best_particle = Particle(self, *np.average(best_particles, axis=0))

        # best_particle = Particle(self.global_map, *avg_particle)
        self.pose = best_particle.get_pose()
        # elif len(best_particles) == 1:
        #     best_particle = Particle(self.global_map, *best_particles)
        
        # rospy.loginfo("Good particles: %s Location: (%s, %s, %s)"%(len(good_particles), avg_particle[0],
        #                                                            avg_particle[1], avg_particle[2]))
        # rospy.loginfo("Best particles: %s Location: (%s, %s, %s)"%(len(best_particles), best_particle.x,
        #                                                            best_particle.y, best_particle.theta))
        print len(self.particles)
        rospy.loginfo("Lowest fit: %s Highest fit: %s"% \
                          (min(particle.fit for particle in self.particles),
                           max(particle.fit for particle in self.particles)))

        particles = PoseArray(poses=[particle.get_pose() for particle in self.particles])
        particles.header.frame_id = FRAME
        self.particle_pub.publish(particles)
        
        self.robot_pose_pub.publish(best_particle.get_stamped_pose())
        self.best_particle = best_particle

        self.reselect_particles()

    def move_particles(self):
        if self.last_odom == None:
            self.last_odom = self.current_odom
            rospy.logwarn("No old odometry assuming no movement.")
            return

        current_orientation = self.current_odom.pose.pose.orientation
        last_orientation = self.last_odom.pose.pose.orientation
        
        dx = self.current_odom.pose.pose.position.x - self.last_odom.pose.pose.position.x
        dy = self.current_odom.pose.pose.position.y - self.last_odom.pose.pose.position.y
        _, _, current_theta = tf.transformations.euler_from_quaternion((
            current_orientation.x, current_orientation.y, current_orientation.z, current_orientation.w))
        _, _, last_theta = tf.transformations.euler_from_quaternion((
            last_orientation.x, last_orientation.y, last_orientation.z, last_orientation.w))
        dtheta = current_theta - last_theta

        for particle in self.particles:
            particle.move(dx, dy, dtheta)
            
        self.last_odom = self.current_odom
        
    def reselect_particles(self):
        particles = []
        new = int(self.num_particles * self.replacement_rate)
        for i in range(self.num_particles - new):
            particle = roulette_wheel(self.particles)
            if particle.is_within_map(self.global_map):
                particles.append(particle)
            else:
                new += 1
        for i in range(new):
            if not self.relocalizing:
                particles.append(self.random_particle(
                        ((self.best_particle.x, self.best_particle.y, self.best_particle.theta),
                         (self.replacement_bias, self.replacement_bias, self.replacement_bias/pi))))
            else:
                particles.append(self.random_particle())
        self.particles = particles
        
    def world_callback(self, grid):
        rospy.loginfo("Global map received")
        # TODO: support grid origin and offset accordingly
        self.world_size = ((0, 0),
                           (grid.info.width * grid.info.resolution, grid.info.height * grid.info.resolution))
        self.global_map = grid
        if self.particles == None: self.initialize_particles()
        
    def cspace_callback(self, grid):
        rospy.loginfo("Cspace map received")
        self.cspace_map = grid

    def pose_callback(self, stamped_pose):
        rospy.loginfo("Stamped pose received")
        pose = stamped_pose.pose.pose
        _, _, theta = tf.transformations.euler_from_quaternion((pose.orientation.x, pose.orientation.y,
                                                                pose.orientation.z, pose.orientation.w))
        rospy.loginfo("Location: (%s, %s, ???)"%(pose.position.x, pose.position.y))

        self.initialize_particles(((pose.position.x, pose.position.y, theta),
                                   (self.user_doubt, self.user_doubt, self.user_doubt/pi)))
        
#        print self.particles

    def odom_callback(self, odom):
        if self.current_odom == None: rospy.loginfo("Odometry received")
        self.current_odom = odom

    def wheel_drop_callback(self, reading):
        if reading.on_ground and not self.was_lifted:
            rospy.loginfo("Still on the ground")
            return
        elif not reading.on_ground:
            rospy.loginfo("Off of the ground.")
            self.was_lifted = True
            return
        else: ## Just got put back down
            rospy.loginfo("Put back on the ground.")
            self.was_lifted = False
            self.robot_pose_valid_pub.publish(Bool(data=False))
            # self.relocalizing = True
            # self.relocalizing_time = 0

            particles = []
            resolution = self.cspace_map.info.resolution
            for x in range(self.cspace_map.info.width):
                for y in range(self.cspace_map.info.height):
                    if grid_get(self.cspace_map, x, y) > 50: continue
                    for theta in [2*pi*i/12.0 for i in range(12)]:
                        particles.append(Particle(self, x*resolution, y*resolution, theta))
            rospy.loginfo("Number of samples %s"%(len(particles)))
            
            particles += [self.random_particle() for i in range(10*self.num_particles)]
            good_particles = []
            for particle in particles:
                lines = line_map_msg_to_lines(self.global_line_map_msg)
                fit = particle.get_fit(lines)
                good_particles.append((fit, particle))

            good_particles.sort(reverse=True)
            self.particles = [particle for _, particle in good_particles][:self.num_particles]
            rospy.loginfo("Number of new particles: %s."%len(self.particles))
            self.robot_pose_valid_pub.publish(Bool(data=True))
        
    def run(self):
        rospy.spin()

if __name__ == "__main__":
    ParticleFilter().run()
