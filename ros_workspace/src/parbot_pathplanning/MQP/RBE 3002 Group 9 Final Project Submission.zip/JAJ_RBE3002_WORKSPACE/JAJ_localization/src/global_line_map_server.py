#!/usr/bin/env python
"""
Generates the global line map based off an occupancy grid.

Subscribes to:
- map_init_lowres: OccupancyGrid The low resolution occupancy grid.

Publishes to:
- global_line_map: LineMap The global line map.
"""

import roslib; roslib.load_manifest('JAJ_localization')
import rospy
from JAJ_localization.msg import LineMap
from nav_msgs.msg import OccupancyGrid, MapMetaData
import numpy as np
import matplotlib.pyplot as plt
from line_core import *
from localization import get_transform, get_vector, grid_get, grid_iter, grid_put

LINE_TOLERANCE = 0.05
MERGE_TOLERANCE = 0.01

offsets4 = [(-1, 0),
            (0, 1),
            (1, 0),
            (0, -1)]
offsets8 = [(-1, 0),
            (-1, 1),
            (0, 1),
            (1, 1),
            (1, 0),
            (1, -1),
            (0, -1),
            (-1, -1)]

def next_valid_point(grid, sx, sy, used):
    # Check for black neighbor
    for dx, dy in offsets4:
        x, y = sx + dx, sy + dy
#        print "\t", x, y
        if (x, y) not in used and grid_get(grid, x, y) == 100:
            # Check for white neighbor
            for dx2, dy2 in offsets8:
                x2, y2 = x + dx2, y + dy2
#                print "\t\t", x2, y2
                if grid_get(grid, x2, y2) == 0:
                    return x, y

class GlobalLineMapServer():
    def __init__(self):
        rospy.init_node("global_line_map_server")
        self.pub = rospy.Publisher("global_line_map", LineMap, latch=True)
        self.sub = rospy.Subscriber("map_init_lowres", OccupancyGrid, self.map_callback)
        rospy.loginfo("GlobalLineMapServer started up")
    
    def map_callback(self, grid):
        rospy.loginfo("Message received")

        # Get all r, theta
        data = [] # [(r, theta, x, y), ...]

        # Get an initial point
        for i, v in enumerate(grid.data):
            if v == 0: break
        initial_x = i % grid.info.width
        initial_y = (i - initial_x)/grid.info.width - 1
        print i, initial_x, initial_y, grid_get(grid, initial_x, initial_y)
        #print grid.data

        used = []
        x, y = next_valid_point(grid, initial_x, initial_y, used)
        while x != initial_x or y != initial_y:
            used.append((x, y))
#            print x, y, grid_get(grid, x, y)
            x_scaled, y_scaled = x*grid.info.resolution, y*grid.info.resolution
            r = sqrt(x_scaled**2 + y_scaled**2)
            theta = atan2(y_scaled, x_scaled)
            data.append((r, theta, x_scaled, y_scaled))
            # print next_valid_point(grid, x, y, used)
            x, y = next_valid_point(grid, x, y, used)
        print "FINAL: ", x, y
        print len(data)

        lines = get_lines(data, LINE_TOLERANCE, MERGE_TOLERANCE)
        print len(lines)
        rospy.loginfo("Lines segmented")

        # print len(lines)
        # for line in lines:
        #     line.plot()
        # plt.axis('equal')
        # plt.show()
        
        self.pub.publish(LineMap(lines=[l.to_line_msg() for l in lines]))
        rospy.loginfo("Message published")

    def run(self):
        rospy.spin()

if __name__ == "__main__":
    GlobalLineMapServer().run()
