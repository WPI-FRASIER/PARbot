#!/usr/bin/env python
"""
Plans a path to follow as the particle filter gets updated.

Subscribes to:
- map: OccupancyGrid The occupancy grid to plan paths based off of.
- particle_pose: PoseStamped The current pose of the robot from the particle filter.
- goal: PoseStamped The goal location.

Publishes to:
- path: PoseArray The path to follow.
"""

import roslib; roslib.load_manifest('JAJ_navigation')
import rospy
from nav_msgs.msg import OccupancyGrid
from geometry_msgs.msg import Point, Pose, PoseStamped, PoseArray
from JAJ_navigation.srv import JAJPlanPath
from math import atan2, pi
from a_star import *
import tf

DELTA = 0.00001 # TODO: parametrize
CUTOFF = 50 # TODO: parametrize
FRAME = "/base_footprint"

offsets4 = [(-1, 0),
            (0, 1),
            (1, 0),
            (0, -1)]
offsets8 = [(-1, 0),
            (-1, 1),
            (0, 1),
            (1, 1),
            (1, 0),
            (1, -1),
            (0, -1),
            (-1, -1)]

class TurtlebotPathPlanner:
    def __init__(self):
        rospy.init_node("turtlebot_path_planner")
        self.grid = None
        self.pose = None
        self.goal = None
        self.nodes = None
        self.resolution = None

        self.path_pub = rospy.Publisher("path", PoseArray, latch=True)
        self.grid_sub = rospy.Subscriber("map", OccupancyGrid, self.grid_callback)
        self.pose_sub = rospy.Subscriber("particle_pose", PoseStamped, self.pose_callback)
        self.pose_sub = rospy.Subscriber("goal", PoseStamped, self.goal_callback)

        rospy.loginfo("Started up")

    def grid_callback(self, grid):
        rospy.loginfo("Grid received")
        self.grid = grid
        self.convert_occupancy_grid(self.grid)

    def pose_callback(self, pose):
        rospy.loginfo("Robot pose received")
        self.pose = pose.pose
        self.plan_path()
        
    def goal_callback(self, goal):
        rospy.loginfo("Goal pose received")
        self.goal = goal.pose
        # path = PoseArray(poses=[self.goal])
        # path.header.frame_id = FRAME
        # self.path_pub.publish(path)
        self.plan_path()

    def convert_occupancy_grid(self, grid):
        "Convert an occupancy grid into a graph"
        # rospy.loginfo("Grid: %s"%grid)
        d = self.resolution = float(grid.info.resolution)
        self.nodes = []
        for y in range(grid.info.height):
            for x in range(grid.info.width):
                if grid.data[y*grid.info.width + x] < CUTOFF:
                    node = Node((d/2+d*x, d/2+d*y))
                    #node = Node((d*x, d*y))
                    self.nodes.append(node)
                else:
                    self.nodes.append(None)

        for node in self.nodes:
            if node == None: continue
            else: self.link(node)

        for i in range(12):
            for node in self.nodes:
                if node == None: continue
                node.distance_to_wall = self.distance_to_wall(node)

                
        for node in self.nodes:
            if node == None: continue
            else:
                print [round(i/0.249-0.5) for i in node.loc], node.distance_to_wall, len(node.neighbors)

        return self.nodes

    def link(self, node):
        x = int(round((node.loc[0]-self.resolution/2) / self.resolution))
        y = int(round((node.loc[1]-self.resolution/2) / self.resolution))
        for dx, dy in offsets8:
            nx, ny = x+dx, y+dy
            if (0 <= nx and nx <= self.grid.info.width) \
                    and (0 <= ny and ny <= self.grid.info.height):
                n = self.nodes[self.grid.info.width*ny + nx]
                if (n != None) and (n != node) and (n not in node.neighbors):
                    # print "Linking: %s:(%s, %s) + (%s, %s) -> %s:(%s, %s)"%(node.loc, x, y, dx, dy,
                    #                                                         n.loc, nx, ny)
                    link(node, n)

    def distance_to_wall(self, node):
        if node.distance_to_wall != None:
            return node.distance_to_wall
        elif len(node.neighbors) < 8: # NOTE: 8-connected only
            return 1
        else:
            neighbors = [n.distance_to_wall for n in node.neighbors if n.distance_to_wall != None]
            return 1 + min(neighbors) if neighbors else None
        

    def closest_node(self, point):
        x = int(round(point.position.x / self.resolution))
        y = int(round(point.position.y / self.resolution))
        return self.nodes[self.grid.info.width*y + x]
        
    def plan_path(self):
        if self.grid == None:
            rospy.logwarn("Trying to plan path, but no map received.")
            return
        elif self.pose == None:
            rospy.logwarn("Trying to plan path, but robot pose has not been recieved.")
            return
        elif self.goal == None:
            rospy.logwarn("Trying to plan path, but goal pose has not been received.")
            return
        elif self.nodes == None:
            rospy.logwarn("Trying to plan path, but nodes have not been initialized.")
            return
        
        rospy.loginfo("Planning path...")

        for node in self.nodes:
            if node:
                node.parent = None
                node.score = maxint
        rospy.loginfo("Nodes reset size: %s"%(len(self.nodes)))

        start = self.closest_node(self.pose)
        target = self.closest_node(self.goal)

        if start == None:
            rospy.logwarn("Trying to plan path, but invalid start location.")
            return
        elif target == None:
            rospy.logwarn("Trying to plan path, but invalid target location.")
            return
        
        rospy.loginfo("start=%s, target=%s"%(start, target))

        path = a_star(start, target, l=0.1)
        rospy.loginfo("Path: %s"%path)
        path = [Node((self.pose.position.x, self.pose.position.y))] + path[1:-1] \
            + [Node((self.goal.position.x, self.goal.position.y))]

        # Publish path as pose array
        poses = []
        for i, wp in enumerate(path):
            next_wp = path[i+1] if i+1 < len(path) else None
            if next_wp != None: desired_orientation = atan2(next_wp.loc[1]-wp.loc[1], next_wp.loc[0]-wp.loc[0])
            else: desired_orientation = 0
            
            pose = Pose()
            pose.position.x = wp.loc[0]
            pose.position.y = wp.loc[1]
            x, y, z, w = tf.transformations.quaternion_from_euler(0, 0, desired_orientation)
            pose.orientation.x, pose.orientation.y = x, y
            pose.orientation.z, pose.orientation.w = z, w
            poses.append(pose)
            
        path = PoseArray(poses=poses)
        path.header.frame_id = FRAME
        self.path_pub.publish(path)
        rospy.loginfo("... Path published")

    def run(self):
        rospy.spin()

if __name__ == "__main__":
    TurtlebotPathPlanner().run()
