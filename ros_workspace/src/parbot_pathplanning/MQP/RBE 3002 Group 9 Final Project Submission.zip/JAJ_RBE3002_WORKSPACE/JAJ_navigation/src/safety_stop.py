#!/usr/bin/env python
"""
Safety stop functionality based off of the reading from the laser scanner.

Subscribes to:
- scan: LaserScan The laser scan from the lidar.

Publishes to:
- cmd_vel: Twist The drive command for the robot.
- safety_stop: Bool Whether or not to stop for an obstacle.
"""

import roslib; roslib.load_manifest('JAJ_navigation')
import rospy
from std_msgs.msg import Bool
from geometry_msgs.msg import Twist, Vector3
from sensor_msgs.msg import LaserScan
from JAJ_navigation.srv import JAJPlanPath
from math import pi, atan2, sqrt
import tf
from dynamic_reconfigure.server import Server as DynamicReconfigureServer
import JAJ_navigation.cfg.FollowPathConfig as Config

class SafetyStop:
    def __init__(self):
        rospy.init_node("safety_stop_monitor")

        self.pub = rospy.Publisher("cmd_vel", Twist)
        self.safety_pub = rospy.Publisher("safety_stop", Bool)
        self.sub = rospy.Subscriber("scan", LaserScan, self.scan_callback)
        rospy.loginfo("Started up")


    def scan_callback(self, scan):
        rospy.loginfo("Message received")

        estop = 0
        
        theta = scan.angle_min
        for r in scan.ranges[::2]:
            if (-pi/6 < theta and theta < pi/6) \
                    and r < 0.33:
                estop += 1
            theta += 2 * scan.angle_increment

        self.safety_pub.publish(Bool(data=(estop > 5)))
        # if estop:
        #     self.pub.publish(Twist(linear=Vector3(x=0, y=0, z=0),
        #                            angular=Vector3(x=0, y=0, z=0)))

    def run(self):
        rospy.spin()

if __name__ == "__main__":
    SafetyStop().run()
