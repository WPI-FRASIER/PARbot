#!/usr/bin/env python
"""
Follows the path provided.

Subscribes to:
- path: PoseArray The path to follow.
- robot_pose: PoseStamped The robots current location and orientation.
- particle_pose_valid: Bool Whether or not the particle pose is currently valid.
- safety_stop: Bool Whether or not there is a safety hazard in the way.

Publishes to:
- target_waypoint: PoseStamped The waypoint that the robot is currently navigating towards.
"""

import roslib; roslib.load_manifest('JAJ_navigation')
import rospy
from std_msgs.msg import Bool
from geometry_msgs.msg import Point, Twist, Vector3
from geometry_msgs.msg import Pose, PoseStamped, PoseArray
from JAJ_navigation.srv import JAJPlanPath
from math import pi, atan2, sqrt
import tf
from dynamic_reconfigure.server import Server as DynamicReconfigureServer
import JAJ_navigation.cfg.FollowPathConfig as Config

FRAME = "/base_footprint"

def pose_distance_to_point(pose, (x, y)):
    return sqrt((pose.position.x - x)**2 + (pose.position.y - y)**2)
        
class PathFollower:
    def __init__(self):
        rospy.init_node("path_follower")
        self.pub = rospy.Publisher("cmd_vel", Twist)
        self.waypoints = None
        self.index = -1
        self.pose = None
        self.estop = False
        self.can_drive = True
        
        self.turn_threshold = None
        self.K_l = self.K_r = self.tolerance = None # Dynamic parameters
        self.dyn_reconf_server = DynamicReconfigureServer(Config, self.reconfigure) 
        
        self.path_sub = rospy.Subscriber("path", PoseArray, self.update_path)
        self.pose_sub = rospy.Subscriber("robot_pose", PoseStamped, self.update_pose)
        self.valid_sub = rospy.Subscriber("particle_pose_valid", Bool, self.valid_pose_update)
        self.safety_sub = rospy.Subscriber("safety_stop", Bool, self.safety_update)
        self.waypoint_pub = rospy.Publisher("target_waypoint", PoseStamped)
        rospy.loginfo("Started up")

    def reconfigure(self, config, level):
        rospy.loginfo("Got reconfigure request!")
        print config
        self.K_l = config["K_l"]
        self.K_r = config["K_r"]
        self.tolerance = config["tolerance"]
        self.turn_threshold = config["turn_threshold"]
        return config

    def update_path(self, path):
        rospy.loginfo("New path received")
        self.waypoints = path.poses
        self.index = -1
        
    def update_pose(self, pose):
        rospy.loginfo("New pose received")
        self.pose = pose.pose
        if self.waypoints == None:
            rospy.logwarn("No path to follow received yet")
        else:
            self.update_steering()

    def update_steering(self):
        ## Get location
        x, y = self.pose.position.x, self.pose.position.y
        orientation = self.pose.orientation
        _, _, theta = tf.transformations.euler_from_quaternion((
                orientation.x, orientation.y, orientation.z, orientation.w))

        ## Calculate starting waypoint if necessary
        if True: #self.index == -1:
            for i, waypoint in enumerate(self.waypoints):
                if pose_distance_to_point(waypoint, [x, y]) < self.tolerance: 
                    self.index = i
            if self.index == -1: self.index = 0
            # rospy.loginfo("Starting at waypoint %s"%(self.index))

        ## Check if next waypoint
        if self.index == len(self.waypoints): return # We're there!
        if pose_distance_to_point(self.waypoints[-1], [x, y]) < self.tolerance: return
        if pose_distance_to_point(self.waypoints[self.index], [x, y]) < self.tolerance:
            self.index += 1
            if self.index == len(self.waypoints): return # We're there!

        ## Navigate to waypoint
        waypoint = self.waypoints[self.index]
        dtheta = atan2(waypoint.position.y - y, waypoint.position.x - x) - theta
        while dtheta > pi: dtheta -= 2*pi
        while dtheta < -pi: dtheta += 2*pi

        if self.estop:
            rospy.loginfo("Stopping for safety.")
            self.drive(0, self.K_r*dtheta)
        elif not self.can_drive:
            rospy.loginfo("Stopping for particle filter.")
            self.drive(0, 0)
        else:
            rospy.loginfo("target=%s, distance=%s, dtheta=%s, target-theta=%s"% \
                              (self.index, pose_distance_to_point(self.waypoints[self.index], [x, y]), dtheta,
                               atan2(waypoint.position.y - y, waypoint.position.x - x)))
            if abs(dtheta) > self.turn_threshold:
                self.drive(0, self.K_r*dtheta)
            else:
                self.drive(self.K_l, 0)

        pose = PoseStamped(pose=waypoint)
        pose.header.frame_id = FRAME
        self.waypoint_pub.publish(pose)
        # rospy.loginfo("Driving")

    def valid_pose_update(self, valid):
        self.can_drive = valid.data

    def safety_update(self, safe):
        self.estop = safe.data

    def drive(self, linear, angular):
        self.pub.publish(Twist(linear=Vector3(x=linear, y=0, z=0),
                               angular=Vector3(x=0, y=0, z=angular)))

    def run(self):
        rospy.spin()

if __name__ == "__main__":
    PathFollower().run()
