#!/usr/bin/env python
import roslib; roslib.load_manifest('JAJ_navigation')
import rospy
from a_star import *
from nav_msgs.msg import OccupancyGrid
from geometry_msgs.msg import Point
from JAJ_navigation.srv import JAJPlanPath, JAJPlanPathResponse

DELTA = 0.00001
CUTOFF = 50

offsets4 = [(-1, 0),
            (0, 1),
            (1, 0),
            (0, -1)]
offsets8 = [(-1, 0),
            (-1, 1),
            (0, 1),
            (1, 1),
            (1, 0),
            (1, -1),
            (0, -1),
            (-1, -1)]

class PathPlanningServiceProvider:
    def __init__(self):
        rospy.init_node("path_planner_server")
        self.serv = rospy.Service('path_planner', JAJPlanPath, self.plan_path)
        rospy.loginfo("Started up")
        self.resolution = None
        self.grid = None
        self.nodes = None
    
    def convert_occupancy_grid(self, grid):
        "Convert an occupancy grid into a graph"
        # rospy.loginfo("Grid: %s"%grid)
        d = self.resolution = grid.info.resolution
        self.nodes = []
        for y in range(grid.info.height):
            for x in range(grid.info.width):
                if grid.data[y*grid.info.width + x] < CUTOFF:
                    node = Node((d/2+d*x, d/2+d*y))
                    #node = Node((d*x, d*y))
                    self.nodes.append(node)
                else:
                    self.nodes.append(None)

        for node in self.nodes:
            if node == None: continue
            else: self.link(node)

        return self.nodes

    def link(self, node):
        x = int(round(node.loc[0] / self.resolution))
        y = int(round(node.loc[1] / self.resolution))
        for dx, dy in offsets8:
            nx, ny = x+dx, y+dy
            if (0 <= nx and nx <= self.grid.info.width) \
                    and (0 <= ny and ny <= self.grid.info.height):
                n = self.nodes[self.grid.info.width*ny + nx]
                if n != None and self not in n.neighbors:
                    # print "Linking: %s:(%s, %s) + (%s, %s) -> %s:(%s, %s)"%(node.loc, x, y, dx, dy,
                    #                                                         n.loc, nx, ny)
                    link(node, n)

    def closest_node(self, point):
        x = int(round(point.x / self.resolution))
        y = int(round(point.y / self.resolution))
        return self.nodes[self.grid.info.width*y + x]
    
    def plan_path(self, req):
        rospy.loginfo("Request made!")
        self.grid = req.grid
        self.nodes = self.convert_occupancy_grid(self.grid)
        rospy.loginfo("Grid size: %s"%(len(self.nodes)))

        start = self.closest_node(req.start)
        target = self.closest_node(req.target)
        rospy.loginfo("start=%s, target=%s"%(start, target))
        path = a_star(start, target)
        rospy.loginfo("Path: %s"%path)
        return JAJPlanPathResponse([Point(x=p.loc[0], y=p.loc[1]) for p in path])
    
    def run(self):
        rospy.spin()

if __name__ == "__main__":
    PathPlanningServiceProvider().run()
