#!/usr/bin/env python
import roslib; roslib.load_manifest('JAJ_localization')
import rospy
from nav_msgs.msg import OccupancyGrid
from JAJ_localization.srv import JAJRegisterGrid, JAJRegisterGridResponse
from math import pi, cos, sin

from localization import get_transform, get_vector, grid_get, grid_iter, grid_put

class MapServer:
    def __init__(self):
        rospy.init_node("map_server")
        self.initial_map = None
        self.map = OccupancyGrid()
        self.pub = rospy.Publisher("map", OccupancyGrid)
        self.sub = rospy.Subscriber("map_init", OccupancyGrid , self.grid_callback)
        self.srv = rospy.Service("map_register_grid", JAJRegisterGrid, self.register_grid)
        rospy.loginfo("Started up")

    def grid_callback(self, grid):
        rospy.loginfo("Getting new initial map, old data lost.")
        self.initial_map = grid
        self.map.data = list(self.initial_map.data[:])
        self.map.info = self.initial_map.info

    def register_grid(self, msg):
        rospy.loginfo("Registering an update.")
        transform = get_transform(msg.pose.x, msg.pose.y, msg.pose.z)
        
        for x, y in grid_iter(msg.grid):
            local_value = grid_get(msg.grid, x, y)
            if local_value == -1: continue
            cosmic = transform * get_vector(int(round(x - msg.grid.info.origin.position.x)),
                                            int(round(y - msg.grid.info.origin.position.y)))
            
            gx, gy = int(round(cosmic[0,0])), int(round(cosmic[1,0]))
            if (not (0 <= gx and gx < self.map.info.width \
                        and 0 <= gy and gy < self.map.info.height)) \
                        or grid_get(self.initial_map, gx, gy) > 50: # Keep old walls
                continue
            
            global_value = grid_get(self.map, gx, gy)
            newval = (local_value + global_value) / 2.0
            grid_put(self.map, gx, gy, newval)
        
        self.pub.publish(self.map)
        return JAJRegisterGridResponse(self.map)

    def run(self):
        rospy.spin()
        # while not rospy.is_shutdown():
        #     self.pub.publish(self.map)
        #     rospy.sleep(0.1)

if __name__ == "__main__":
    MapServer().run()
